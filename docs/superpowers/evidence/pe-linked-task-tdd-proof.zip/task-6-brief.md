### Task 6: Verify visible state, fresh installation and policy documentation

**Files:** Modify the staff/student appointment readers, `README.md`, `docs/current-policies.md` and `package.json`. Extend `src/server/repositories/appointments.repository.test.ts`, `src/server/laboratory/pe-linked-laboratory.integration.test.ts` and `src/server/services/student-result-submissions.integration.test.ts`. Create the guarded browser fixture and `docs/superpowers/evidence/2026-10-08-pe-linked-external-laboratory-completion.md` with actual executed results.

**Interfaces:** Current appointment/result readers consume persisted completion. Fixture supports `setup`, `status` and `cleanup`; package commands are `acceptance:pe-linked-laboratory:setup`, `acceptance:pe-linked-laboratory:status` and `acceptance:pe-linked-laboratory:cleanup`, each invoking `tsx --env-file=.env.local scripts/browser-pe-linked-laboratory-fixture.ts <action>`.

- [ ] **Step 1: Add reader/document tests.** Use `getStudentPortalSchedule(studentNumber)` against the migrated database to assert the exact first-year awaiting-confirmation label before PE and saved COMPLETED after, together with the staff appointment reader. OJT clinical completion does not finalize a document or bypass verified-email/ownership upload gates. First-year completion creates no upload draft/file. Preserve unverified authenticated reading and authorized certificate downloads.
- [ ] **Step 2: Update both first-year display-label SQL expressions.** Replace `Awaiting External Laboratory Result` with the spec's exact new label in both staff readers and the student portal.
- [ ] **Step 3: Create the synthetic browser fixture.** Use complete import/snapshot/OVPSA provenance, runtime Manila dates, valid one-day ordinary/seven-day first-year separation, and active physician profiles. Include an OJT missing-manual case, OJT 3/4-ready case, first-year 0/4-ready case and an ordinary control. Require `BROWSER_PE_LINKED_ACCEPTANCE_LOCAL_TEST_DB=1`, a named loopback test database and matching saved database identity for cleanup; follow existing fixture protections. Add only its package scripts.
- [ ] **Step 4: Run browser acceptance on the disposable local instance.** As KABALAKA staff check OJT CBC/Urine/Stool; observe disabled X-ray and 3/4 PENDING. As CPU staff verify OJT/first-year PE list and detail readiness, preview unchanged state, and submit Class A plus a remarked B/C/D case. Reload Laboratory/PE and inspect persisted evidence through fixture status.
- [ ] **Step 5: Verify student and scheduling effects.** Log in as the affected student, see completed appointments and download the correct private JPG. Confirm no unexpected draft/file, extra hospital appointment, capacity charge or duplicate notification. Confirm ordinary controls retain their old prerequisite.
- [ ] **Step 6: Update current documentation after behavior passes.** Record these rules and narrow supersession of September 22/27 external-test prerequisites. Keep unrelated policies and fresh capacity defaults. Add executed command results, synthetic screenshots/state evidence and unresolved limitations to the evidence document; never mark unexecuted checks as passed.
- [ ] **Step 7: Run final gates once after the last code change.** Run `npm test`, `npm run test:integration`, `npm run test:migrations:empty`, `npm run lint`, `npx tsc --noEmit` and `npm run build`. Supply the existing test-runner PostgreSQL configuration and use its disposable-database harness; do not point tests or resets at a user's working database.
- [ ] **Step 8: Clean up the browser fixture and verify status.** Cleanup only the saved matching synthetic fixture; retain necessary acceptance artifacts.
- [ ] **Step 9: Commit.** Suggested message: `docs: record PE-linked laboratory completion acceptance`.

## Execution notes and completion gate

Read both this plan and its spec before implementation. Follow root `AGENTS.md` and read the installed Next.js guide before modifying framework code. Inspect baseline drift and map names to current files without reverting another person's changes.

`scripts/test-integration.ts` passes path filters through to Vitest and creates/migrates/seeds a disposable database. Use the commands above rather than direct integration runs against application data. Because there is no schema change, keep the existing migration ledger and trigger inventory intact.

Stop implementation completion claims until A1–A15 in the spec have corresponding verified evidence, all final gates pass and the user-visible workflow has been exercised. A documentation-only commit does not establish these results.

Implementation is a separate task. This handoff does not implement, deploy or publish the revised application.
