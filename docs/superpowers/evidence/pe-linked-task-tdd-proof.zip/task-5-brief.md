### Task 5: Prove replacement, concurrency and existing database invariants

**Files:** Extend `pe-linked-laboratory.integration.test.ts`, `laboratory-checklist.integration.test.ts`, `src/server/services/appointments-locking.integration.test.ts` and `src/server/db/final-defense-schema.integration.test.ts`. Do not add a migration.

**Interfaces:** Exercise the public checklist/PE services and existing replacement/no-show operations against a disposable migrated database.

- [ ] **Step 1: Add effective-lineage tests.** Replace an eligible Laboratory appointment with the same checklist and verify the old ID cannot receive confirmation; the new effective pair alone completes. Cover valid current first-year reservation ownership and a wrong-revision pairing.
- [ ] **Step 2: Add deterministic race tests using synchronization barriers, not timing sleeps.** Pause issuance after rendering; uncheck one manual OJT test or replace an appointment in another transaction; resume issuance and expect `EXAMINATION_STALE` with no automatic effects.
- [ ] **Step 3: Add concurrent-request tests.** Same actor/request/payload returns one outcome; competing distinct requests yield at most one issuance and one set of external item events. Include a no-show sweep racing OJT checks and verify recorded progress cannot become NO_SHOW.
- [ ] **Step 4: Extend schema assertions.** At commit, COMPLETED Laboratory requires all four tests for these contexts, PE requires its one issued certificate/result, and OVPSA summary remains unique. Assert an independent direct status-only completion still fails existing constraints. Retain immutable history checks.
- [ ] **Step 5: Run `npm run test:integration -- src/server/laboratory/pe-linked-laboratory.integration.test.ts src/server/laboratory/laboratory-checklist.integration.test.ts src/server/services/appointments-locking.integration.test.ts src/server/db/final-defense-schema.integration.test.ts`.** Require every scenario to pass without disabling constraints in the behavior under test.
- [ ] **Step 6: Commit the meaningful regressions.** Suggested message: `test: verify atomic PE laboratory confirmation and races`.

