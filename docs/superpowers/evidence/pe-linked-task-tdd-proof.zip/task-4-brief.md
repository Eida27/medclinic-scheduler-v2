### Task 4: Expose one consistent staff workflow

**Files:** Modify `LaboratoryChecklist.tsx`, `PhysicalExamCompletionForm.tsx` and `AppointmentDetail.tsx`. Extend checklist/form/dialog tests and `src/app/(dashboard)/physical-exam/[appointmentId]/page.test.tsx`. Extend `src/app/api/appointments/[appointmentId]/physical-exam-completion-context/route.test.ts`. Create `src/app/api/appointments/[appointmentId]/complete-physical-exam/route.test.ts` and `src/app/api/appointments/[appointmentId]/physical-exam-certificate-preview/route.test.ts`.

**Interfaces:** Consume checklist `completionPolicy` and `PhysicalExamCompletionContext.laboratoryCompletion`. Use existing dialog-to-form flow; no new endpoint or request field.

- [ ] **Step 1: Write failing UI tests.** OJT has four boxes with only X-ray disabled; first year has four disabled boxes. Assert the spec's exact explanatory text. Clicking PE-managed tests sends no PATCH; manual OJT checks still send the versioned PATCH.
- [ ] **Step 2: Run `npm test -- src/components/appointments/LaboratoryChecklist.test.tsx src/components/appointments/PhysicalExamCompletionForm.test.tsx src/components/appointments/PhysicalExamCompletionDialog.test.tsx`.** Confirm new policy/copy assertions fail before implementing controls.
- [ ] **Step 3: Implement checklist controls.** Apply both whole-view permission/readOnly and policy-based per-item restrictions. Missing policy must not expose editable external controls; show a load error until valid server context exists.
- [ ] **Step 4: Update detail and completion form.** Make paired Laboratory read-only on every PE detail, remove manual first-year instructions, and render the relevant single attestation/external-test summary. Keep existing form validation, busy state, uncertain-response same-request retry, JPG preview and successful refresh.
- [ ] **Step 5: Add list/detail and cancellation assertions.** Both paths allow eligible OJT/first-year PE, expose missing manual blockers, and do not optimistically change boxes. Closing the dialog or clicking preview sends no checklist PATCH or completion POST.
- [ ] **Step 6: Test route contracts.** Completion preserves current dataResponse/outcome and private/no-store; preview returns only private JPEG bytes; context exposes readiness without adding signature bytes or mutations. Keep UUID and Admin/Clinic Staff guards.
- [ ] **Step 7: Verify the UI and route suites.** Run the Step 2 command and `npm test -- "src/app/(dashboard)/physical-exam/[appointmentId]/page.test.tsx" "src/app/api/appointments/[appointmentId]/physical-exam-completion-context/route.test.ts" "src/app/api/appointments/[appointmentId]/complete-physical-exam/route.test.ts" "src/app/api/appointments/[appointmentId]/physical-exam-certificate-preview/route.test.ts"`.
- [ ] **Step 8: Commit.** Suggested message: `feat: show PE-managed hospital tests in clinical workflows`.

