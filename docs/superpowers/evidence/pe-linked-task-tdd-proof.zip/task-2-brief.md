### Task 2: Protect PE-managed items from manual PATCH

**Files:** Modify `laboratory-checklist.service.ts`. Extend `laboratory-checklist.integration.test.ts` and `src/app/api/appointments/[appointmentId]/laboratory-checklist/route.test.ts`. Create the new PE-linked service module for the extracted external finalizer.

**Interfaces:** Consume Task 1's policy. Produce `completeExternalLaboratoryWithClient` with the contract above and unchanged `setLaboratoryTestVerification` request/return shapes.

- [ ] **Step 1: Write failing integration tests.** Build first-year fixtures using `acceptAndScheduleImport` with valid FIRST_YEAR_OVPSA provenance, following `first-year-schedule-import.integration.test.ts`. For OJT XRAY and each first-year test, submit both `checked: true` and `checked: false` and assert `LABORATORY_TEST_PE_MANAGED`/422 plus unchanged item state, version, events and appointment. Add the explicit CPU-staff/OJT-CBC forbidden assertion.
- [ ] **Step 2: Run `npm run test:integration -- src/server/laboratory/laboratory-checklist.integration.test.ts`.** Confirm new PE-managed tests fail under current manual behavior.
- [ ] **Step 3: Enforce the per-test guard after current actor/pair validation and before no-op return or any mutation.** Preserve normal manual verification, version conflict, automatic-no-show reason, protected-result and certificate-history rules.
- [ ] **Step 4: Extract the external finalizer.** Validate effective appointment's batch/revision/provider; use the unique appointment verification record without replacing previous identity. Preserve existing result status protection and completion semantics. Import the helper back into the checklist service while avoiding circular imports.
- [ ] **Step 5: Update endpoint tests for the domain error.** Expect 422 and the spec's exact error message; keep actor/UUID checks unchanged.
- [ ] **Step 6: Verify the selected integration and route tests.** Run the integration command from Step 2 and `npm test -- "src/app/api/appointments/[appointmentId]/laboratory-checklist/route.test.ts"`.
- [ ] **Step 7: Commit.** Suggested message: `fix: reserve external test confirmation for PE completion`.

