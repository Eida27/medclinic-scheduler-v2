### Task 1: Define completion ownership from immutable provenance

**Files:** Create the shared types, policy module and `src/server/laboratory/laboratory-completion-policy.test.ts`. Modify the requirements and checklist repository files above. Extend `laboratory-requirements.test.ts` where needed.

**Interfaces:** Produce `resolveLaboratoryCompletionPolicy(context: { yearLevel: number | null | undefined; schedulingCategory: string | null | undefined; isOvpsaFirstYear: boolean }): LaboratoryCompletionPolicy` and checklist `completionPolicy`. Consume existing `requiredLaboratoryTests`.

- [ ] **Step 1: Write policy tests with exact outputs.** Cover first-year valid OVPSA, fourth-year OJT, fourth-year Regular/Tour, other supported years, and invalid/missing provenance. Example assertion:

```ts
expect(resolveLaboratoryCompletionPolicy({
  yearLevel: 4, schedulingCategory: "OJT", isOvpsaFirstYear: false,
})).toEqual({
  mode: "FOURTH_YEAR_OJT",
  manualTestCodes: ["CBC", "URINE", "STOOL"],
  peConfirmedTestCodes: ["XRAY"],
  externalProvider: "Iloilo Mission Hospital",
});
```

- [ ] **Step 2: Run the new policy tests and record the expected missing-module/function failure.** Run `npm test -- src/server/laboratory/laboratory-completion-policy.test.ts`.
- [ ] **Step 3: Implement the shared types and resolver.** STANDARD keeps the existing required set; first year without valid OVPSA and OVPSA on another year throw `LABORATORY_PROVENANCE_MISSING` (409).
- [ ] **Step 4: Extend the checklist query/record.** Select immutable checklist year/category and the linked appointment's complete OVPSA identity; derive policy from these values. Preserve versions, item sources and replacement links.
- [ ] **Step 5: Add a repository integration assertion in `laboratory-checklist.integration.test.ts`.** Alter a fixture student's live year after snapshot creation and assert the checklist's OJT policy/required XRAY is unchanged; a replacement shares the same policy.
- [ ] **Step 6: Verify.** Run `npm test -- src/server/laboratory/laboratory-completion-policy.test.ts src/server/laboratory/laboratory-requirements.test.ts` and `npm run test:integration -- src/server/laboratory/laboratory-checklist.integration.test.ts`. Require all selected tests to pass.
- [ ] **Step 7: Commit this policy/DTO change.** Suggested message: `feat: define PE-managed external laboratory tests`.

